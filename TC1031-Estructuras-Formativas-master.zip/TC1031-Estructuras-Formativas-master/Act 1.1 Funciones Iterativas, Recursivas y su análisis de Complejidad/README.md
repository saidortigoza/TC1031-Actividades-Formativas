#suma Iterativa

**Análisis de complejidad temporal**

el algoritmo recorre n pasos ya que usa un ciclo que va i = 1 hatsa n, por los que su complejidad es O(n*n) para el peor de los casos.

#suma Recursiva

**Análisis de complejidad temporal**

El algoritmo se manda a llamar así mismo n veces, por los que su complejidad es O(n*n*n) para el peor de los casos.
